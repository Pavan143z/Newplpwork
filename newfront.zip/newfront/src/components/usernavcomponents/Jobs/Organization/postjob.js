import React from 'react'
import Card from 'react-bootstrap/Card';
import {  CardText, CardBody, CardHeader,CardFooter} from 'reactstrap';
import axios from 'axios';
import {Link} from 'react-router-dom';
class PostJob extends React.Component {
    constructor() {
        super()
        this.state = { jobpost: [] }
    
    }

    
    baseurl = "  http://localhost:3002/PostJob";
    getPost = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ jobpost: response.data })
            console.log(this.state.jobpost)
        });
    }
    addjobPost = (jobpost) => {
      console.log(jobpost)
        axios.post(this.baseurl, jobpost).then((response) => {
            this.getPost();
            alert("Post added")
        })
    }
    
    componentDidMount() {
        this.getPost();
    }
      jobpost = React.createRef();
      handleAddJobPost = () => {
          let contObject = { jobpost: this.jobpost.current.value }
          this.addjobPost(contObject)
      }
    render() {
        return (
            <div>       
        <div className="text-right">         <button className="btn btn-info "><Link to="/"> Logoff</Link> </button>       </div>  
            <div className="jumbotron" >
                <div className="container">
                    <div className="row">
                    <Card>
          <CardHeader>
            <form className="form-group">
            <textarea type="text" className="form-control" placeholder="Post Here....." ref={this.jobpost}>
            </textarea>
            </form>
          </CardHeader>
          <CardBody>
            <button className="btn btn-outline-dark" onClick={this.handleAddJobPost}>Add Job Post</button>
          </CardBody>
        </Card>

                </div>
                </div>
                <hr />
                {/* <footer className="text-center" font-family="Open Sams">
                 <i>   “The candidate pool on LinkedIn is simply higher caliber. Professionals choose to represent themselves on LinkedIn versus other networks.”
                 </i> <img src={require('../Organization/img1.jpg')} width="150 " />
                    <p align="right ">Julie Leslie,<br />

                        The Howard Group</p>
                </footer> */}
                </div>
            </div>



        )
    }
}
export default PostJob;