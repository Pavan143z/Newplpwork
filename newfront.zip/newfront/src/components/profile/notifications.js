import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';
import Notifications from '../usernavcomponents/Notification/Notifications';


export class UserNotification extends Component {
    render() {
        const signup = this.props.userData;
        return (
            <div className="backC">
                <UserNavComponent />
             <Notifications/>
            </div>
        )
    }
}

export default UserNotification
