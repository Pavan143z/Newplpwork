import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';
import MyNetwork from '../usernavcomponents/UserNetwork/MyNetwork';
export class UserNetwork extends Component {
    render() {
        const signup = this.props.userData;
        return (
            <div className="backC">
                <UserNavComponent />
               <MyNetwork/>
            </div>
        )
    }
}

export default UserNetwork
