import React from "react";
import { Link } from "react-router-dom";

export const UserNavComponent = () => {
  // logout = () => {
  //   localStorage.clear();
  //   window.location.href = "/";
  // };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className="container-fluid">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
            Linkedin
          </Link>
        </div>

        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1"
        >
          <ul className="nav navbar-nav">
            <li>
              <Link class="glyphicon glyphicon-home" to="/home">
                &nbsp;Home
              </Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link to="/mynetwork">My Network</Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link to="/userjob">&nbsp;Jobs</Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link to="/notifications">Notifications</Link>
              <span className="sr-only" />
            </li>
          </ul>

          <ul className="nav navbar-nav navbar-right">
            <li>
              <Link class="glyphicon glyphicon-user" to="/myprofile">
                &nbsp;Me
              </Link>
            </li>
            <div>
              <a href="http://localhost:3003">LOGOUT</a>

              <div>
                {/* <a href="#" onClick={this.logout()}>
                  LOGOUT
                </a> */}
              </div>
            </div>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default UserNavComponent;
