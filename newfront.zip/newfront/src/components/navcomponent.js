import React from "react";
import { Link } from "react-router-dom";

export const NavComponent = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className ="container-fluid">
         <div className="navbar-header">
          <Link className="navbar-brand" to="/">
           Home
          </Link>
        </div> 

        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav">
            <li>
              <Link to="/about">About Us</Link>
              <span className="sr-only" />
            </li>
          </ul>

          <ul className="nav navbar-nav navbar-right">
          <div className="text-right">    <button className="btn btn-info "><Link to="/"> Logoff</Link> </button>       </div>  
            <li>
              <Link class="glyphicon glyphicon-log-in" to="/login">&nbsp;Login</Link>
            </li>
            <li>
              <Link class="glyphicon glyphicon-user" to="/register">&nbsp;Register</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default NavComponent;
