import React from "react";
import axios from "axios";
import { Redirect } from "react-router";
import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.routeChange = this.routeChange.bind(this);
    this.onChangeUsername = this.onChangeUsername.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      email: "",
      password: "",
      login: [],
      redirect: "",
      flag: false
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:3002/Signup")
      .then(response => {
        this.setState({
          login: response.data
        });
        console.log(this.login);
      })
      .catch(function(error) {
        console.log(error);
      });
  }
  onSubmit(e) {
    e.preventDefault();
    this.enteredUsername = this.state.email;
    this.enteredPassword = this.state.password;
    console.log(this.state.login.length);
    for (let i = 0; i < this.state.login.length; i++) {
      if (
        this.enteredUsername === this.state.login[i].email &&
        this.enteredPassword === this.state.login[i].password
      ) {
        this.setState({
          flag: true,
          redirect: true
        });
        this.flag2 = true;
        break;
      } else {
        this.setState({
          flag: false,
          redirect: false
        });
        this.flag2 = false;
      }
    }
    sessionStorage.setItem("username",this.state.email)
    console.log("value=>" + this.state.redirect);
    if (this.flag2 === false) {
      alert("Wrong username and password");
    }
  }
  onChangeUsername(e) {
    this.setState({
      email: e.target.value
    });
  }
  onChangePassword(e) {
    this.setState({
      password: e.target.value
    });
  }
  routeChange(id) {
    let path = `/userhome`;
    this.props.history.push(path);
  }

  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      alert("Login Successfully");
      return <Redirect to="/userhome" />;
    }
    return (
      <div>
      <div className="container">
        <div className="col-lg-4">
          <br />
          <br />
          <h2 className="text-center">Login To<font color="red"> YouJoin</font></h2>
          <form onSubmit={this.onSubmit}>
            <br />

            <div className="form-group">
              <label className="text-info">
                <h3>
                  &nbsp;Email{" "}
                </h3>
              </label>
              <input
                type="text"
                className="form-control"
                placeholder="Email"
                value={this.state.email}
                onChange={this.onChangeUsername}
              />
            </div>
            <div className="form-group">
              <label className="text-info">
                <h3>
                 
                  &nbsp;Password{" "}
                </h3>
              </label>
              <input
                type="password"
                className="form-control"
                placeholder="Password"
                value={this.state.password}
                onChange={this.onChangePassword}
              />
            </div>

            <div className="form-group">
              <input type="submit" value="Signup" className="btn btn-primary" />
              &nbsp;&nbsp;&nbsp;
             
              <Link to="/">Back</Link>
            </div>
          </form>
        </div>
      </div>
      </div>
    );
  }
}

export default Login;
